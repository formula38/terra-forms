# 🧊 Coldchain Secure CLI (coldchainctl)

### Usage

Install:
```bash
cd scripts/cli
chmod +x install.sh
./install.sh
```

Uninstall:
```bash
cd scripts/cli
./uninstall.sh
```

Run:
```bash
coldchainctl help
```

---

### Available Commands
- `coldchainctl plan` → terraform init + plan + JSON
- `coldchainctl html [dark|light]` → generate HTML report
- `coldchainctl full [dark|light]` → full terraform + html workflow
