#!/bin/bash
set -e
echo "🗑️ Uninstalling coldchainctl CLI..."
sudo rm -f /usr/local/bin/coldchainctl
echo "✅ Removed coldchainctl!"
