#!/bin/bash
set -e
echo "📦 Installing coldchainctl CLI (symlink method)..."
chmod +x ./coldchainctl
sudo rm -f /usr/local/bin/coldchainctl
sudo ln -s "$(pwd)/coldchainctl" /usr/local/bin/coldchainctl
echo "✅ Installed! You can now run:"
echo
echo "    coldchainctl help"
echo
